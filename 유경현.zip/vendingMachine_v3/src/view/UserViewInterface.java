package view;

public interface UserViewInterface {
//    boolean registerView();
//    LoginDto loginView();
//    void userBuyView(LoginDto loginDto);
}
